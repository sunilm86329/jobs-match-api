# Job Match API

A small Spring Boot REST API that recommends jobs to candidates using a transparent, explainable rule-based scoring model.

## Tech Stack

- Java 17
- Spring Boot 3.5
- Spring Web
- Spring Validation
- Maven
- JUnit 5
- In-memory repositories

No authentication, authorization, frontend, or machine learning is included because they are explicitly out of scope.

## How to Run Locally

Requirements:

- JDK 17+
- Maven 3.9+

Run:

```bash
mvn clean test
mvn spring-boot:run
```

The API starts on:

```text
http://localhost:8080
```

## Docker

Build:

```bash
docker build -t job-match-api .
```

Run:

```bash
docker run --rm -p 8080:8080 job-match-api
```

## API Endpoints

### Create candidate

`POST /api/candidates`

Example:

```json
{
  "name": "Sunil Kumar",
  "skills": ["Angular", "TypeScript", "Java", "Spring Boot"],
  "yearsOfExperience": 2.2,
  "location": "Hyderabad",
  "expectedSalary": 700000
}
```

### Create job

`POST /api/jobs`

Example:

```json
{
  "title": "Full Stack Developer",
  "requiredSkills": [
    {"name": "Angular", "type": "MUST_HAVE"},
    {"name": "Java", "type": "MUST_HAVE"},
    {"name": "Spring Boot", "type": "MUST_HAVE"},
    {"name": "Docker", "type": "NICE_TO_HAVE"}
  ],
  "minYearsExperience": 3,
  "location": "Hyderabad",
  "salaryRange": {
    "min": 600000,
    "max": 1000000
  },
  "remoteAllowed": true
}
```

### Recommendations

`GET /api/candidates/{candidateId}/recommendations?limit=5`

The default limit is 10 and the API accepts values from 1 to 100.

Example response:

```json
[
  {
    "jobId": 1,
    "title": "Full Stack Developer",
    "overallScore": 88.33,
    "breakdown": {
      "skills": 50.0,
      "experience": 13.33,
      "location": 15.0,
      "salary": 15.0
    }
  }
]
```

## Scoring Formula

The maximum score is 100 points:

| Dimension | Weight |
|---|---:|
| Skills | 50 |
| Experience | 20 |
| Location | 15 |
| Salary | 15 |
| Total | 100 |

### 1. Skills: 50 points

Skills are intentionally the largest component because a candidate must be technically capable of performing the role.

The 50 points are divided into:

- Must-have skills: 40 points
- Nice-to-have skills: 10 points

Formula:

```text
mustHaveScore = matchedMustHave / totalMustHave * 40
niceToHaveScore = matchedNiceToHave / totalNiceToHave * 10

skillScore = mustHaveScore + niceToHaveScore
```

If there are no skills in one category, that category receives its full allocated points. In normal job data, required skills should be present.

### Must-have hard filter

Before scoring, every MUST_HAVE skill is checked.

If the candidate is missing even one must-have skill, the job is removed from recommendations.

This is intentionally a hard filter because the requirement explicitly says a missing must-have skill should never appear regardless of other scores.

Nice-to-have skills never gate a candidate out.

### 2. Experience: 20 points

Experience is a soft factor rather than a hard filter.

If the candidate meets or exceeds the minimum:

```text
experienceScore = 20
```

If the candidate is below the minimum:

```text
experienceScore =
candidateYears / minimumYears * 20
```

The score is capped at 20.

For example:

```text
Candidate = 2 years
Job minimum = 3 years

2 / 3 * 20 = 13.33
```

I chose to penalize rather than exclude because years of experience are not a perfect proxy for capability. A candidate with slightly less experience but strong relevant skills can still be a valuable match.

### 3. Location: 15 points

The required ordering is:

```text
Exact location match > remote > mismatch
```

Therefore:

```text
Exact match = 15
Remote allowed but location differs = 10
Location differs and remote is unavailable = 0
```

This gives a small preference to candidates who can work from the requested location while still recognizing remote opportunities.

### 4. Salary: 15 points

If the candidate's expected salary is less than or equal to the job's maximum salary, the candidate receives the full 15 points.

This means a job whose range contains the candidate's expectation scores highly, as does a job that comfortably exceeds the expectation.

If the entire job range is below the candidate's expectation, the score is reduced according to:

```text
salaryScore = jobMax / expectedSalary * 15
```

The result is capped between 0 and 15.

Example:

```text
Expected salary = 7 LPA
Job maximum = 6 LPA

6 / 7 * 15 = 12.86
```

This intentionally makes a job with a maximum significantly below the candidate's expectation less attractive.

## Recommendation Flow

```text
Candidate
   |
   v
Load all jobs
   |
   v
Hard-filter missing MUST_HAVE skills
   |
   v
Calculate skill score
   |
   +--> experience score
   |
   +--> location score
   |
   +--> salary score
   |
   v
Sum to overall score
   |
   v
Sort descending
   |
   v
Apply top-N limit
   |
   v
Return explainable recommendations
```

## Design Decisions

### Why separate scorer classes?

Each scoring dimension is implemented separately. This keeps the business rules easy to read, test, change, and explain.

For example, salary logic can change without modifying the recommendation orchestration.

### Why in-memory storage?

Persistence is not part of the required problem. In-memory repositories keep the assignment focused on the matching algorithm and API design.

With more time, I would use PostgreSQL and Spring Data JPA.

### Why no authentication?

Authentication and authorization are explicitly out of scope.

### Why no machine learning?

The requirement asks for transparent and explainable recommendations. A deterministic rule-based scorer makes every recommendation auditable.

## Assumptions

- Salary values are annual salary amounts in the same currency/unit for candidates and jobs. The API does not perform currency conversion.
- Skill matching is case-insensitive and ignores leading/trailing whitespace.
- Location matching is case-insensitive.
- A remote job receives a score of 10 when the candidate's location does not exactly match.
- Recommendation scores are rounded to two decimal places.
- A recommendation limit must be between 1 and 100.
- Candidate and job IDs are generated by the in-memory repositories.
- There is no update/delete endpoint because only creation and recommendation endpoints are required.

## Testing

The project includes unit tests for:

- Missing must-have skills
- Nice-to-have skills
- Experience penalty
- Experience full score
- Exact/remote/mismatched locations
- Salary inside range
- Salary below expectation
- Salary above expectation
- Recommendation ranking
- Recommendation limit
- Must-have filtering

Run:

```bash
mvn clean test
```

## What I Would Do Differently With More Time

1. Add PostgreSQL persistence with Spring Data JPA.
2. Add pagination for large job datasets.
3. Add a richer salary scoring curve that distinguishes "inside range" from "far above expectation".
4. Add more sophisticated skill normalization/synonyms, such as `Spring` vs `Spring Framework`.
5. Add OpenAPI/Swagger documentation.
6. Add integration tests using MockMvc/Testcontainers.
7. Add structured logging and metrics.
8. Add configurable scoring weights rather than hard-coded weights.
9. Add update/delete APIs and candidate/job search.
10. Add caching or pre-computed indexes if the job catalog becomes large.

## AI Usage

AI tools were used for brainstorming project structure, reviewing edge cases, and generating initial implementation ideas. The scoring model and business-rule interpretation were reviewed manually. In particular, the hard-filter behavior, experience penalty, location ordering, and salary behavior were deliberately chosen to satisfy the assignment while keeping the scorer transparent.

AI-generated suggestions were edited rather than accepted blindly, and the final code was organized into separate scoring components with tests for the core business rules.

## License

This project is provided as an assignment/demo project.
