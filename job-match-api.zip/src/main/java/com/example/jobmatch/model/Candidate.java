package com.example.jobmatch.model;

import jakarta.validation.constraints.*;

import java.util.List;

public record Candidate(
        Long id,

        @NotBlank String name,

        @NotEmpty List<@NotBlank String> skills,

        @DecimalMin("0.0") double yearsOfExperience,

        @NotBlank String location,

        @PositiveOrZero double expectedSalary
) {}
