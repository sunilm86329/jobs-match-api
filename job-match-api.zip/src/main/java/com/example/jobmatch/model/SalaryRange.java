package com.example.jobmatch.model;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

public record SalaryRange(
        @NotNull @DecimalMin("0.0") Double min,
        @NotNull @DecimalMin("0.0") Double max
) {
    public SalaryRange {
        if (min != null && max != null && min > max) {
            throw new IllegalArgumentException("salaryRange.min must be less than or equal to salaryRange.max");
        }
    }
}
