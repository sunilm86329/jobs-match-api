package com.example.jobmatch.model;

public enum SkillType {
    MUST_HAVE,
    NICE_TO_HAVE
}
