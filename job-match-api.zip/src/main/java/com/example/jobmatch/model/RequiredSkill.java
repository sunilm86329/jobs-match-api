package com.example.jobmatch.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record RequiredSkill(
        @NotBlank String name,
        @NotNull SkillType type
) {}
