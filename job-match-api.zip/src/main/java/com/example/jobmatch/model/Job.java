package com.example.jobmatch.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

import java.util.List;

public record Job(
        Long id,

        @NotBlank String title,

        @NotEmpty List<@Valid RequiredSkill> requiredSkills,

        @DecimalMin("0.0") double minYearsExperience,

        @NotBlank String location,

        @NotNull @Valid SalaryRange salaryRange,

        boolean remoteAllowed
) {}
