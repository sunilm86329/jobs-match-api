package com.example.jobmatch.controller;

import com.example.jobmatch.dto.RecommendationResponse;
import com.example.jobmatch.service.RecommendationService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/candidates")
public class RecommendationController {
    private final RecommendationService service;

    public RecommendationController(RecommendationService service) {
        this.service = service;
    }

    @GetMapping("/{candidateId}/recommendations")
    public List<RecommendationResponse> recommend(
            @PathVariable long candidateId,
            @RequestParam(defaultValue = "10") int limit) {
        return service.recommend(candidateId, limit);
    }
}
