package com.example.jobmatch.scorer;

import com.example.jobmatch.model.Candidate;
import com.example.jobmatch.model.Job;
import org.springframework.stereotype.Component;

@Component
public class SalaryScorer {
    private static final double MAX_SCORE = 15.0;

    public double score(Candidate candidate, Job job) {
        double expected = candidate.expectedSalary();
        double min = job.salaryRange().min();
        double max = job.salaryRange().max();

        if (expected <= max) {
            return MAX_SCORE;
        }

        // The job's maximum is below the candidate's expectation.
        // The further below expectation, the lower the score.
        if (expected <= 0) {
            return 0.0;
        }

        double ratio = max / expected;
        return round(Math.max(0.0, Math.min(MAX_SCORE, ratio * MAX_SCORE)));
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
