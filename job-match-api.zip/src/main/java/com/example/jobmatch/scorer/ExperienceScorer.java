package com.example.jobmatch.scorer;

import com.example.jobmatch.model.Candidate;
import com.example.jobmatch.model.Job;
import org.springframework.stereotype.Component;

@Component
public class ExperienceScorer {
    private static final double MAX_SCORE = 20.0;

    public double score(Candidate candidate, Job job) {
        if (job.minYearsExperience() <= 0) {
            return MAX_SCORE;
        }

        double ratio = candidate.yearsOfExperience() / job.minYearsExperience();
        return round(Math.min(MAX_SCORE, Math.max(0.0, ratio * MAX_SCORE)));
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
