package com.example.jobmatch.scorer;

import com.example.jobmatch.model.Candidate;
import com.example.jobmatch.model.Job;
import org.springframework.stereotype.Component;

@Component
public class LocationScorer {
    public double score(Candidate candidate, Job job) {
        if (candidate.location().trim().equalsIgnoreCase(job.location().trim())) {
            return 15.0;
        }
        return job.remoteAllowed() ? 10.0 : 0.0;
    }
}
