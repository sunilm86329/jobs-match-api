package com.example.jobmatch.scorer;

import com.example.jobmatch.model.Candidate;
import com.example.jobmatch.model.Job;
import com.example.jobmatch.model.RequiredSkill;
import com.example.jobmatch.model.SkillType;
import org.springframework.stereotype.Component;

import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class SkillScorer {

    public boolean passesMustHaveFilter(Candidate candidate, Job job) {
        Set<String> candidateSkills = normalized(candidate.skills());

        return job.requiredSkills().stream()
                .filter(s -> s.type() == SkillType.MUST_HAVE)
                .allMatch(s -> candidateSkills.contains(normalize(s.name())));
    }

    public double score(Candidate candidate, Job job) {
        Set<String> candidateSkills = normalized(candidate.skills());

        long mustTotal = job.requiredSkills().stream()
                .filter(s -> s.type() == SkillType.MUST_HAVE).count();
        long mustMatched = job.requiredSkills().stream()
                .filter(s -> s.type() == SkillType.MUST_HAVE)
                .filter(s -> candidateSkills.contains(normalize(s.name()))).count();

        long niceTotal = job.requiredSkills().stream()
                .filter(s -> s.type() == SkillType.NICE_TO_HAVE).count();
        long niceMatched = job.requiredSkills().stream()
                .filter(s -> s.type() == SkillType.NICE_TO_HAVE)
                .filter(s -> candidateSkills.contains(normalize(s.name()))).count();

        double mustScore = mustTotal == 0 ? 40.0 : (mustMatched * 40.0 / mustTotal);
        double niceScore = niceTotal == 0 ? 10.0 : (niceMatched * 10.0 / niceTotal);

        return round(mustScore + niceScore);
    }

    private Set<String> normalized(java.util.List<String> skills) {
        return skills.stream().map(this::normalize).collect(Collectors.toSet());
    }

    private String normalize(String value) {
        return value.trim().toLowerCase(Locale.ROOT);
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
