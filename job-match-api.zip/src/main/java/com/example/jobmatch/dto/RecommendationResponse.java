package com.example.jobmatch.dto;

public record RecommendationResponse(
        Long jobId,
        String title,
        double overallScore,
        ScoreBreakdown breakdown
) {}
