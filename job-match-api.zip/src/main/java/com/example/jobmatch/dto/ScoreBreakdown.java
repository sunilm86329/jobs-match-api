package com.example.jobmatch.dto;

public record ScoreBreakdown(
        double skills,
        double experience,
        double location,
        double salary
) {}
