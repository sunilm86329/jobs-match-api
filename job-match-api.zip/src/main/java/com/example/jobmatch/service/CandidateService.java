package com.example.jobmatch.service;

import com.example.jobmatch.model.Candidate;
import com.example.jobmatch.repository.CandidateRepository;
import org.springframework.stereotype.Service;

@Service
public class CandidateService {
    private final CandidateRepository repository;

    public CandidateService(CandidateRepository repository) {
        this.repository = repository;
    }

    public Candidate create(Candidate candidate) {
        return repository.save(candidate);
    }

    public Candidate get(long id) {
        return repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Candidate not found: " + id));
    }
}
