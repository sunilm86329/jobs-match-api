package com.example.jobmatch.service;

import com.example.jobmatch.dto.RecommendationResponse;
import com.example.jobmatch.dto.ScoreBreakdown;
import com.example.jobmatch.model.Candidate;
import com.example.jobmatch.model.Job;
import com.example.jobmatch.repository.JobRepository;
import com.example.jobmatch.scorer.*;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
public class RecommendationService {
    private final CandidateService candidateService;
    private final JobRepository jobRepository;
    private final SkillScorer skillScorer;
    private final ExperienceScorer experienceScorer;
    private final LocationScorer locationScorer;
    private final SalaryScorer salaryScorer;

    public RecommendationService(
            CandidateService candidateService,
            JobRepository jobRepository,
            SkillScorer skillScorer,
            ExperienceScorer experienceScorer,
            LocationScorer locationScorer,
            SalaryScorer salaryScorer) {
        this.candidateService = candidateService;
        this.jobRepository = jobRepository;
        this.skillScorer = skillScorer;
        this.experienceScorer = experienceScorer;
        this.locationScorer = locationScorer;
        this.salaryScorer = salaryScorer;
    }

    public List<RecommendationResponse> recommend(long candidateId, int limit) {
        if (limit < 1 || limit > 100) {
            throw new IllegalArgumentException("limit must be between 1 and 100");
        }

        Candidate candidate = candidateService.get(candidateId);

        return jobRepository.findAll().stream()
                .filter(job -> skillScorer.passesMustHaveFilter(candidate, job))
                .map(job -> toRecommendation(candidate, job))
                .sorted(Comparator.comparingDouble(RecommendationResponse::overallScore).reversed())
                .limit(limit)
                .toList();
    }

    private RecommendationResponse toRecommendation(Candidate candidate, Job job) {
        double skills = skillScorer.score(candidate, job);
        double experience = experienceScorer.score(candidate, job);
        double location = locationScorer.score(candidate, job);
        double salary = salaryScorer.score(candidate, job);

        double total = round(skills + experience + location + salary);

        return new RecommendationResponse(
                job.id(),
                job.title(),
                total,
                new ScoreBreakdown(skills, experience, location, salary)
        );
    }

    private double round(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
