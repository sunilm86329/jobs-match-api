package com.example.jobmatch.service;

import com.example.jobmatch.model.Job;
import com.example.jobmatch.repository.JobRepository;
import org.springframework.stereotype.Service;

@Service
public class JobService {
    private final JobRepository repository;

    public JobService(JobRepository repository) {
        this.repository = repository;
    }

    public Job create(Job job) {
        return repository.save(job);
    }
}
