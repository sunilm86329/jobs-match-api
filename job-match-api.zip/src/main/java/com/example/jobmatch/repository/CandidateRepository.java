package com.example.jobmatch.repository;

import com.example.jobmatch.model.Candidate;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

@Repository
public class CandidateRepository {
    private final Map<Long, Candidate> candidates = new LinkedHashMap<>();
    private final AtomicLong sequence = new AtomicLong(1);

    public synchronized Candidate save(Candidate candidate) {
        long id = candidate.id() == null ? sequence.getAndIncrement() : candidate.id();
        Candidate saved = new Candidate(id, candidate.name(), candidate.skills(),
                candidate.yearsOfExperience(), candidate.location(), candidate.expectedSalary());
        candidates.put(id, saved);
        return saved;
    }

    public Optional<Candidate> findById(long id) {
        return Optional.ofNullable(candidates.get(id));
    }
}
