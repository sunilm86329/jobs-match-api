package com.example.jobmatch.repository;

import com.example.jobmatch.model.Job;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

@Repository
public class JobRepository {
    private final Map<Long, Job> jobs = new LinkedHashMap<>();
    private final AtomicLong sequence = new AtomicLong(1);

    public synchronized Job save(Job job) {
        long id = job.id() == null ? sequence.getAndIncrement() : job.id();
        Job saved = new Job(id, job.title(), job.requiredSkills(), job.minYearsExperience(),
                job.location(), job.salaryRange(), job.remoteAllowed());
        jobs.put(id, saved);
        return saved;
    }

    public List<Job> findAll() {
        return List.copyOf(jobs.values());
    }
}
