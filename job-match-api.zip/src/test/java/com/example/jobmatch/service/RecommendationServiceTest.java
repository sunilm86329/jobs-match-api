package com.example.jobmatch.service;

import com.example.jobmatch.dto.RecommendationResponse;
import com.example.jobmatch.model.*;
import com.example.jobmatch.repository.*;
import com.example.jobmatch.scorer.*;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RecommendationServiceTest {

    @Test
    void returnsRankedResultsAndHonorsLimit() {
        CandidateRepository candidates = new CandidateRepository();
        JobRepository jobs = new JobRepository();

        Candidate candidate = candidates.save(new Candidate(null, "A",
                List.of("Java", "Angular"), 3, "Hyderabad", 700000));

        jobs.save(new Job(null, "Good Match",
                List.of(new RequiredSkill("Java", SkillType.MUST_HAVE),
                        new RequiredSkill("Angular", SkillType.MUST_HAVE)),
                2, "Hyderabad", new SalaryRange(600000.0, 1000000.0), true));

        jobs.save(new Job(null, "Bad Location",
                List.of(new RequiredSkill("Java", SkillType.MUST_HAVE)),
                2, "Bengaluru", new SalaryRange(500000.0, 600000.0), false));

        jobs.save(new Job(null, "Blocked",
                List.of(new RequiredSkill("Python", SkillType.MUST_HAVE)),
                1, "Hyderabad", new SalaryRange(1000000.0, 1500000.0), true));

        CandidateService candidateService = new CandidateService(candidates);
        RecommendationService service = new RecommendationService(
                candidateService, jobs,
                new SkillScorer(), new ExperienceScorer(),
                new LocationScorer(), new SalaryScorer());

        List<RecommendationResponse> results = service.recommend(candidate.id(), 1);

        assertEquals(1, results.size());
        assertEquals("Good Match", results.get(0).title());
        assertTrue(results.get(0).overallScore() > 0);
    }
}
