package com.example.jobmatch.scorer;

import com.example.jobmatch.model.*;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class LocationScorerTest {
    private final LocationScorer scorer = new LocationScorer();

    private Candidate candidate() {
        return new Candidate(null, "A", List.of("Java"), 2, "Hyderabad", 700000);
    }

    private Job job(String location, boolean remote) {
        return new Job(null, "Developer",
                List.of(new RequiredSkill("Java", SkillType.MUST_HAVE)),
                1, location, new SalaryRange(500000.0, 1000000.0), remote);
    }

    @Test void exactMatchGetsHighestScore() {
        assertEquals(15.0, scorer.score(candidate(), job("Hyderabad", false)));
    }

    @Test void remoteGetsMiddleScore() {
        assertEquals(10.0, scorer.score(candidate(), job("Bengaluru", true)));
    }

    @Test void mismatchGetsZero() {
        assertEquals(0.0, scorer.score(candidate(), job("Bengaluru", false)));
    }
}
