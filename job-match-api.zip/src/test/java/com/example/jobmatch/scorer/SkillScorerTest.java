package com.example.jobmatch.scorer;

import com.example.jobmatch.model.*;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SkillScorerTest {
    private final SkillScorer scorer = new SkillScorer();

    @Test
    void missingMustHaveSkillFailsHardFilter() {
        Candidate candidate = new Candidate(null, "A", List.of("Java"), 2, "Hyderabad", 700000);
        Job job = new Job(null, "Developer",
                List.of(new RequiredSkill("Java", SkillType.MUST_HAVE),
                        new RequiredSkill("Angular", SkillType.MUST_HAVE)),
                1, "Hyderabad", new SalaryRange(500000.0, 1000000.0), false);

        assertFalse(scorer.passesMustHaveFilter(candidate, job));
    }

    @Test
    void niceToHaveSkillDoesNotGateCandidate() {
        Candidate candidate = new Candidate(null, "A", List.of("Java"), 2, "Hyderabad", 700000);
        Job job = new Job(null, "Developer",
                List.of(new RequiredSkill("Java", SkillType.MUST_HAVE),
                        new RequiredSkill("Docker", SkillType.NICE_TO_HAVE)),
                1, "Hyderabad", new SalaryRange(500000.0, 1000000.0), false);

        assertTrue(scorer.passesMustHaveFilter(candidate, job));
        assertEquals(40.0, scorer.score(candidate, job));
    }
}
