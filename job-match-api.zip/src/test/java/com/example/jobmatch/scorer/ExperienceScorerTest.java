package com.example.jobmatch.scorer;

import com.example.jobmatch.model.*;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ExperienceScorerTest {
    private final ExperienceScorer scorer = new ExperienceScorer();

    @Test
    void belowMinimumIsPenalizedNotExcluded() {
        Candidate candidate = new Candidate(null, "A", List.of("Java"), 2, "Hyderabad", 700000);
        Job job = new Job(null, "Developer",
                List.of(new RequiredSkill("Java", SkillType.MUST_HAVE)),
                3, "Hyderabad", new SalaryRange(500000.0, 1000000.0), false);

        assertEquals(13.33, scorer.score(candidate, job), 0.01);
    }

    @Test
    void experienceAtOrAboveMinimumGetsFullScore() {
        Candidate candidate = new Candidate(null, "A", List.of("Java"), 4, "Hyderabad", 700000);
        Job job = new Job(null, "Developer",
                List.of(new RequiredSkill("Java", SkillType.MUST_HAVE)),
                3, "Hyderabad", new SalaryRange(500000.0, 1000000.0), false);

        assertEquals(20.0, scorer.score(candidate, job));
    }
}
