package com.example.jobmatch.scorer;

import com.example.jobmatch.model.*;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SalaryScorerTest {
    private final SalaryScorer scorer = new SalaryScorer();

    private Candidate candidate(double expected) {
        return new Candidate(null, "A", List.of("Java"), 2, "Hyderabad", expected);
    }

    private Job job(double min, double max) {
        return new Job(null, "Developer",
                List.of(new RequiredSkill("Java", SkillType.MUST_HAVE)),
                1, "Hyderabad", new SalaryRange(min, max), false);
    }

    @Test void expectationInsideRangeGetsFullScore() {
        assertEquals(15.0, scorer.score(candidate(700000), job(600000, 1000000)));
    }

    @Test void jobBelowExpectationGetsReducedScore() {
        assertEquals(12.86, scorer.score(candidate(700000), job(500000, 600000)), 0.01);
    }

    @Test void jobAboveExpectationGetsFullScore() {
        assertEquals(15.0, scorer.score(candidate(700000), job(800000, 1200000)));
    }
}
